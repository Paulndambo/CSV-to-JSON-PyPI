def hello_world(name: str):
    """
    Takes in a string,
    : returns a string
    : parameters name: str
    """
    return f"Hello {name}"