def hello_world(name: str):
    """
    Takes in a string,
    : returns a string
    """
    return f"Hello {name}"